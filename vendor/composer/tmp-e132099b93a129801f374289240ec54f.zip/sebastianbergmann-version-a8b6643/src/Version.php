<?php declare(strict_types=1);
/*
 * This file is part of sebastian/version.
 *
 * (c) Sebastian Bergmann <sebastian@phpunit.de>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
namespace SebastianBergmann;

use const DIRECTORY_SEPARATOR;
use function array_slice;
use function assert;
use function end;
use function explode;
use function fclose;
use function implode;
use function is_dir;
use function is_resource;
use function proc_close;
use function proc_open;
use function stream_get_contents;
use function substr_count;
use function trim;

final readonly class Version
{
    /**
     * @var non-empty-string
     */
    private string $version;

    /**
     * @param non-empty-string $release
     * @param non-empty-string $path
     */
    public function __construct(string $release, string $path)
    {
        $this->version = $this->generate($release, $path);
    }

    /**
     * @return non-empty-string
     */
    public function asString(): string
    {
        return $this->version;
    }

    /**
     * @param non-empty-string $release
     * @param non-empty-string $path
     *
     * @return non-empty-string
     */
    private function generate(string $release, string $path): string
    {
        if (substr_count($release, '.') + 1 === 3) {
            $version = $release;
        } else {
            $version = $release . '-dev';
        }

        $git = $this->getGitInformation($path, $release);

        if ($git === false) {
            return $version;
        }

        if (substr_count($release, '.') + 1 === 3) {
            return $git;
        }

        $git = explode('-', $git);

        return $release . '-' . end($git);
    }

    /**
     * @param non-empty-string $path
     * @param non-empty-string $release
     *
     * @return false|non-empty-string
     */
    private function getGitInformation(string $path, string $release): false|string
    {
        if (!is_dir($path . DIRECTORY_SEPARATOR . '.git')) {
            return false;
        }

        if (substr_count($release, '.') + 1 === 3) {
            $series = implode('.', array_slice(explode('.', $release), 0, 2));

            $result = $this->describe($path, ['--match', $series . '.*']);

            if ($result !== false) {
                return $result;
            }

            return $this->describe($path, []);
        }

        // Without --long, "git describe" prints only the name of the tag when
        // HEAD is tagged; with it, the output always ends with the abbreviated
        // hash of HEAD, which is what the version string for a release series
        // ends with
        return $this->describe($path, ['--long']);
    }

    /**
     * @param non-empty-string $path
     * @param list<string>     $arguments
     *
     * @return false|non-empty-string
     */
    private function describe(string $path, array $arguments): false|string
    {
        $process = @proc_open(
            ['git', 'describe', '--tags', ...$arguments],
            [
                1 => ['pipe', 'w'],
                2 => ['pipe', 'w'],
            ],
            $pipes,
            $path,
        );

        if (!is_resource($process)) {
            return false;
        }

        assert(isset($pipes[1]) && is_resource($pipes[1]));
        assert(isset($pipes[2]) && is_resource($pipes[2]));

        $result = trim((string) stream_get_contents($pipes[1]));

        fclose($pipes[1]);
        fclose($pipes[2]);

        $returnCode = proc_close($process);

        if ($returnCode !== 0) {
            return false;
        }

        assert($result !== '');

        return $result;
    }
}
